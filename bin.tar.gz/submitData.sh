#!/bin/bash
crab submit -c crab3_data_cfg_B.py;
crab submit -c crab3_data_cfg_C.py;
crab submit -c crab3_data_cfg_D.py;
crab submit -c crab3_data_cfg_E.py;
crab submit -c crab3_data_cfg_F.py;
crab submit -c crab3_data_cfg_G.py;
crab submit -c crab3_data_cfg_H.py;
