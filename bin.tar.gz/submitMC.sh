#!/bin/bash
crab submit -c crab3_MC_cfg1.py;
crab submit -c crab3_MC_cfg2.py;
crab submit -c crab3_MC_cfg3.py;
crab submit -c crab3_MC_cfg4.py;
crab submit -c crab3_MC_cfg5.py;
crab submit -c crab3_MC_cfg6.py;
crab submit -c crab3_MC_cfg7.py;
crab submit -c crab3_MC_cfg8.py;
