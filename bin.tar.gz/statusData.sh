#!/bin/bash
crab status crab3_projects/crab_Charmonium_Run2016B-07Aug17_ver2-v1_AOD;
crab status crab3_projects/crab_Charmonium_Run2016C-07Aug17-v1_AOD;
crab status crab3_projects/crab_Charmonium_Run2016D-07Aug17-v1_AOD;
crab status crab3_projects/crab_Charmonium_Run2016E-07Aug17-v1_AOD;
crab status crab3_projects/crab_Charmonium_Run2016H-07Aug17-v1_AOD;
