#!/bin/bash
crab report -d crab3_projects/crab_BsToJpsiPhi_BMuonFilter_2016_AODSIM;
crab report -d crab3_projects/crab_BsToJpsiPhi_BMuonFilter_DGamma0_2016_AODSIM;
crab report -d crab3_projects/crab_BuToJpsiK_BMuonFilter_2016_AODSIM;
crab report -d crab3_projects/crab_BdToJpsiKstar_BMuonFilter_2016_AODSIM;
crab report -d crab3_projects/crab_BdToKstarMuMu_BMuonFilter_2016_AODSIM;
crab report -d crab3_projects/crab_InclusiveMu_MuonPt3_2016_AODSIM;
crab report -d crab3_projects/crab_bbbarToMuMu_MuonPt3_2016_AODSIM;
crab report -d crab3_projects/crab_BToJPsiKMu_JpsiMuMu_2016_AODSIM;
